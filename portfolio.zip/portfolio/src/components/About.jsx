import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, GraduationCap, Briefcase, User } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Content */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-7"
          >
            <div className="glass-card p-8 rounded-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
               <h3 className="text-2xl font-semibold mb-4 text-white flex items-center gap-2">
                 <User className="text-primary-400" size={24} />
                 The Short Version
               </h3>
               <p className="text-slate-300 leading-relaxed mb-6 text-lg">
                 I am a results-oriented B.Tech CSE (AIML) student at Manav Rachna with a passion for building robust web applications and integrating intelligent ML models. My unique background allows me to bridge the gap between user-centric web development and data-driven AI systems.
               </p>
               <p className="text-slate-300 leading-relaxed text-lg mb-6">
                 With a published research paper in IoT and multiple industry-recognized certifications, I am constantly exploring new technologies. I thrive in Agile environments and am eager to contribute my skills in full-stack development and machine learning to forward-thinking teams.
               </p>

               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8 pt-8 border-t border-white/10">
                 <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/5 rounded-lg text-accent-400"><GraduationCap size={20} /></div>
                    <div>
                      <p className="text-sm text-slate-400">Education</p>
                      <p className="text-sm font-medium">B.Tech CSE (AIML)</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/5 rounded-lg text-primary-400"><Briefcase size={20} /></div>
                    <div>
                      <p className="text-sm text-slate-400">Experience</p>
                      <p className="text-sm font-medium">Web Dev Internships</p>
                    </div>
                 </div>
               </div>
            </div>
          </motion.div>

          {/* Quick Stats / Info */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="glass p-6 rounded-2xl border border-white/5 flex items-start gap-4">
               <div className="p-3 bg-gradient-to-br from-primary-500/20 to-primary-600/10 rounded-xl text-primary-400 mt-1">
                 <MapPin />
               </div>
               <div>
                  <h4 className="font-semibold text-white mb-1">Location</h4>
                  <p className="text-slate-400 text-sm">India</p>
               </div>
            </div>

            <div className="glass p-6 rounded-2xl border border-white/5">
                <h4 className="font-semibold text-white mb-4">Core Focus</h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-300">Full-Stack Development</span>
                      <span className="text-primary-400">90%</span>
                    </div>
                    <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                      <div className="h-full bg-primary-500 w-[90%] rounded-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-300">Machine Learning / AI</span>
                      <span className="text-accent-400">85%</span>
                    </div>
                    <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                      <div className="h-full bg-accent-500 w-[85%] rounded-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-300">Data Structures & Algo</span>
                      <span className="text-purple-400">80%</span>
                    </div>
                    <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                      <div className="h-full bg-purple-500 w-[80%] rounded-full"></div>
                    </div>
                  </div>
                </div>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
}

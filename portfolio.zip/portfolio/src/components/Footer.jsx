import React from 'react';
import { Github, Linkedin, Mail, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-dark-900 border-t border-white/5 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
        
        <div className="text-center md:text-left">
          <a href="#" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-accent-400 inline-block mb-2">
            SA.
          </a>
          <p className="text-slate-400 text-sm">Design & Built by Saif Ahmed</p>
        </div>

        <div className="flex items-center gap-6">
          <a href="https://github.com/saif-ahmed65" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white transition-colors">
            <Github size={20} />
            <span className="sr-only">GitHub</span>
          </a>
          <a href="https://www.linkedin.com/in/saif-ahmed65/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-[#0077b5] transition-colors">
            <Linkedin size={20} />
            <span className="sr-only">LinkedIn</span>
          </a>
          <a href="mailto:saifamd65@gmail.com" className="text-slate-400 hover:text-primary-400 transition-colors">
            <Mail size={20} />
            <span className="sr-only">Email</span>
          </a>
        </div>

        <div className="text-slate-400 text-sm flex items-center justify-center gap-1">
          Made with <Heart size={14} className="text-red-500 fill-red-500 mx-1" /> © {new Date().getFullYear()}
        </div>
        
      </div>
    </footer>
  );
}

import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Database, Layout, Terminal, BrainCircuit, LineChart } from 'lucide-react';

const skillCategories = [
  {
    title: "Web Development",
    icon: <Layout className="text-primary-400" />,
    skills: ["HTML", "CSS", "JavaScript", "React.js", "Tailwind CSS"],
    color: "from-primary-500/20 to-primary-600/5",
    border: "border-primary-500/20"
  },
  {
    title: "AI & Machine Learning",
    icon: <BrainCircuit className="text-accent-400" />,
    skills: ["Machine Learning", "Data Preprocessing", "Model Evaluation", "NumPy", "Pandas", "Scikit-learn"],
    color: "from-accent-500/20 to-accent-600/5",
    border: "border-accent-500/20"
  },
  {
    title: "Programming & CS Core",
    icon: <Code2 className="text-purple-400" />,
    skills: ["Python", "C", "Data Structures", "OOPs", "DBMS", "Operating Systems", "Computer Networks"],
    color: "from-purple-500/20 to-purple-600/5",
    border: "border-purple-500/20"
  },
  {
    title: "Development Tools",
    icon: <Terminal className="text-orange-400" />,
    skills: ["Git", "GitHub", "Jupyter Notebook", "Agile Methodologies"],
    color: "from-orange-500/20 to-orange-600/5",
    border: "border-orange-500/20"
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Technical Skills</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className={`glass-card p-8 rounded-2xl border ${category.border} bg-gradient-to-br ${category.color} hover:shadow-lg hover:shadow-black/50 transition-all`}
            >
              <div className="flex items-center gap-4 mb-6 pb-6 border-b border-white/5">
                <div className="p-3 bg-dark-900 rounded-xl shadow-inner">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold text-white">{category.title}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1.5 text-sm font-medium bg-dark-900/50 text-slate-300 rounded-lg border border-white/5 hover:border-white/20 transition-colors"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

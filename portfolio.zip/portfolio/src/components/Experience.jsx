import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Calendar } from 'lucide-react';

const experiences = [
  {
    role: "Web Development Intern",
    company: "Cognifyz Technologies",
    date: "July 2025 – Aug 2025",
    type: "On-site / Real-time",
    points: [
      "Developed responsive web pages using modern HTML, CSS, and JavaScript standards.",
      "Assisted in frontend UI enhancements and basic backend development tasks.",
      "Worked on real-time projects following industry-standard development workflows.",
      "Collaborated with cross-functional teams to significantly improve User Experience (UX)."
    ]
  },
  {
    role: "Web Development Intern",
    company: "CodSoft",
    date: "June 2024 – July 2024",
    type: "Virtual",
    points: [
      "Completed intensive web development tasks and mini-projects within strict deadlines.",
      "Strengthened foundational concepts in HTML, CSS, and advanced JavaScript.",
      "Followed agile-like deadlines, greatly improving independent problem-solving skills."
    ]
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 relative bg-dark-800/20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.5 }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Experience</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="relative border-l border-white/10 ml-3 md:ml-0 md:border-l-0 md:flex md:flex-col md:items-center">
          {/* Central line for desktop */}
          <div className="hidden md:block absolute top-0 bottom-0 left-1/2 w-px bg-white/10 -translate-x-1/2"></div>
          
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className={`mb-12 relative w-full md:flex ${index % 2 === 0 ? 'md:justify-start' : 'md:justify-end'} items-center`}
            >
              {/* Timeline dot */}
              <div className="absolute -left-[21px] md:left-1/2 w-10 h-10 rounded-full bg-dark-900 border-4 border-dark-800 flex items-center justify-center z-10 md:-translate-x-1/2">
                <div className="w-3 h-3 rounded-full bg-primary-500 shadow-[0_0_10px_rgba(59,130,246,0.6)]"></div>
              </div>

              {/* Content Card */}
              <div className={`ml-8 md:ml-0 md:w-5/12 ${index % 2 === 0 ? 'md:pr-12 text-left' : 'md:pl-12 md:text-left'}`}>
                <div className="glass-card p-6 md:p-8 rounded-2xl hover:-translate-y-1 transition-transform duration-300 relative group overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-primary-500/5 rounded-full blur-xl group-hover:bg-primary-500/10 transition-colors"></div>
                  
                  <div className="flex flex-col mb-4">
                    <span className="text-primary-400 font-semibold mb-1">{exp.role}</span>
                    <h3 className="text-xl font-bold text-white mb-2">{exp.company}</h3>
                    <div className="flex items-center gap-4 text-sm text-slate-400">
                      <span className="flex items-center gap-1"><Calendar size={14} /> {exp.date}</span>
                      <span className="flex items-center gap-1"><Briefcase size={14} /> {exp.type}</span>
                    </div>
                  </div>
                  
                  <ul className="space-y-2 mt-4">
                    {exp.points.map((point, i) => (
                      <li key={i} className="text-slate-300 text-sm md:text-base flex items-start gap-2">
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-accent-500/50 flex-shrink-0"></span>
                        <span className="leading-relaxed">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

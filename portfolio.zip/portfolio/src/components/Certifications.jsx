import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Award, Star } from 'lucide-react';

const certifications = [
  {
    name: "Oracle Certified",
    title: "AI Vector Search",
    year: "2025",
    icon: <ShieldCheck className="text-red-400" size={32} />,
    color: "from-red-500/10 to-transparent",
    border: "border-red-500/20"
  },
  {
    name: "Microsoft Certified",
    title: "Azure AI Fundamentals",
    year: "2025",
    icon: <Award className="text-blue-400" size={32} />,
    color: "from-blue-500/10 to-transparent",
    border: "border-blue-500/20"
  },
  {
    name: "NPTEL (IIT Kanpur)",
    title: "Machine Learning",
    year: "Completed",
    icon: <Star className="text-yellow-400" size={32} />,
    color: "from-yellow-500/10 to-transparent",
    border: "border-yellow-500/20"
  },
  {
    name: "Infosys Springboard",
    title: "Graphs & OOPs",
    year: "Completed",
    icon: <ShieldCheck className="text-primary-400" size={32} />,
    color: "from-primary-500/10 to-transparent",
    border: "border-primary-500/20"
  }
];

export default function Certifications() {
  return (
    <section id="certifications" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.5 }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Certifications</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`glass-card p-6 rounded-2xl border ${cert.border} bg-gradient-to-br ${cert.color} text-center flex flex-col items-center justify-center hover:-translate-y-2 transition-transform duration-300`}
            >
              <div className="mb-4 bg-dark-900/50 p-4 rounded-full shadow-inner">
                {cert.icon}
              </div>
              <h4 className="text-slate-400 text-sm font-semibold mb-1 uppercase tracking-wider">{cert.name}</h4>
              <h3 className="text-lg font-bold text-white mb-3">{cert.title}</h3>
              <span className="text-xs font-bold px-3 py-1 bg-white/5 rounded-full text-slate-300 mt-auto">
                {cert.year}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

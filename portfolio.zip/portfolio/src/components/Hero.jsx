import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Download, Github, Linkedin, Mail } from 'lucide-react';

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background decoration elements */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-primary-500/20 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob"></div>
      <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-accent-500/20 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-8 left-1/3 w-72 h-72 bg-purple-500/20 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob animation-delay-4000"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center px-3 py-1 rounded-full border border-primary-500/30 bg-primary-500/10 text-primary-400 text-sm font-medium mb-6"
        >
          <span className="flex h-2 w-2 rounded-full bg-primary-500 mr-2"></span>
          Available for Internships
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-5xl md:text-7xl font-extrabold tracking-tight mb-4"
        >
          Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-accent-400">Saif Ahmed</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-xl md:text-2xl text-slate-400 font-light mb-8 max-w-2xl mx-auto"
        >
          Building intelligent solutions with <span className="text-white font-medium">code</span> and <span className="text-white font-medium">creativity</span>.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 items-center mb-12"
        >
          <a href="#projects" className="flex items-center gap-2 bg-white text-dark-900 px-8 py-3 rounded-full font-semibold hover:bg-slate-200 transition-colors">
            View My Work <ArrowRight size={18} />
          </a>
          <a href="#" className="flex items-center gap-2 glass px-8 py-3 rounded-full font-semibold hover:bg-white/10 transition-colors">
            <Download size={18} /> Download Resume
          </a>
        </motion.div>

        <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           transition={{ duration: 0.5, delay: 0.6 }}
           className="flex items-center gap-6"
        >
          <a href="https://github.com/saif-ahmed65" target="_blank" rel="noopener noreferrer" className="p-3 glass rounded-full hover:bg-white/10 transition-colors text-slate-300 hover:text-white">
            <Github size={24} />
            <span className="sr-only">GitHub</span>
          </a>
          <a href="https://www.linkedin.com/in/saif-ahmed65/" target="_blank" rel="noopener noreferrer" className="p-3 glass rounded-full hover:bg-[#0077b5]/20 hover:text-[#0077b5] transition-colors text-slate-300">
            <Linkedin size={24} />
            <span className="sr-only">LinkedIn</span>
          </a>
          <a href="mailto:saifamd65@gmail.com" className="p-3 glass rounded-full hover:bg-primary-500/20 hover:text-primary-400 transition-colors text-slate-300">
            <Mail size={24} />
            <span className="sr-only">Email</span>
          </a>
        </motion.div>

      </div>
    </section>
  );
}

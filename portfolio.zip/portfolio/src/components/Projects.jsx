import React from 'react';
import { motion } from 'framer-motion';
import { Github, ExternalLink, Activity } from 'lucide-react';

const projects = [
  {
    title: "Iris Flower Classification Pipeline",
    description: "Built a fully-fledged Machine Learning pipeline for multi-class classification of Iris species. Employed an ensemble of algorithms to accurately predict classes.",
    image: "https://images.unsplash.com/photo-1596547609652-9fc5d8d42dcd?q=80&w=800&auto=format&fit=crop",
    tech: ["Python", "Scikit-learn", "Pandas", "Matplotlib"],
    highlights: [
      "Tested LR, KNN, Decision Tree, Random Forest, SVM & Naive Bayes",
      "Applied K-Means clustering for exploratory analysis",
      "Achieved peak performance via SVM & Random Forest tuning"
    ],
    links: {
      github: "#",
      demo: "#"
    }
  },
  // Add another placeholder project to make the grid look full, users usually have 2+ projects
  {
    title: "Portfolio Website",
    description: "A modern, highly responsive personal portfolio designed to showcase projects, experience, and research. Built with modern web technologies and optimized for performance.",
    image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?q=80&w=800&auto=format&fit=crop",
    tech: ["React.js", "Tailwind CSS", "Framer Motion", "Vite"],
    highlights: [
      "Custom UI with Glassmorphism aesthetics",
      "Framer Motion based animations",
      "Fully responsive mobile-first design"
    ],
    links: {
      github: "#",
      demo: "#"
    }
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.5 }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Projects</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="group glass-card rounded-2xl overflow-hidden flex flex-col h-full"
            >
              {/* Image Container */}
              <div className="relative h-64 overflow-hidden">
                <div className="absolute inset-0 bg-dark-900/40 group-hover:bg-transparent transition-colors z-10"></div>
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
              </div>

              {/* Content */}
              <div className="p-8 flex-grow flex flex-col">
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary-400 transition-colors">{project.title}</h3>
                <p className="text-slate-300 mb-6 flex-grow">{project.description}</p>
                
                <div className="mb-6 space-y-2">
                  {project.highlights.map((highlight, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-slate-400">
                      <Activity size={16} className="text-accent-500 mt-0.5 flex-shrink-0" />
                      <span>{highlight}</span>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap gap-2 mb-8">
                  {project.tech.map((tech) => (
                    <span key={tech} className="px-3 py-1 text-xs font-semibold bg-primary-500/10 text-primary-300 rounded-full border border-primary-500/20">
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-4 mt-auto">
                  <a href={project.links.github} className="flex items-center gap-2 text-sm font-semibold text-white hover:text-primary-400 transition-colors px-4 py-2 glass rounded-lg">
                    <Github size={18} /> Code
                  </a>
                  <a href={project.links.demo} className="flex items-center gap-2 text-sm font-semibold text-white hover:text-accent-400 transition-colors px-4 py-2 glass rounded-lg">
                    <ExternalLink size={18} /> Live Demo
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

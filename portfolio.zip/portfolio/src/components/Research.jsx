import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, CheckCircle } from 'lucide-react';

export default function Research() {
  return (
    <section id="research" className="py-24 relative bg-dark-800/20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.5 }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Research & Publications</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full"></div>
        </motion.div>

        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           transition={{ duration: 0.6 }}
           className="relative"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary-500/20 to-accent-500/20 rounded-3xl blur-xl pb-4"></div>
          
          <div className="relative glass-card p-8 md:p-12 rounded-3xl border border-white/10 overflow-hidden flex flex-col md:flex-row gap-8 items-center">
            
            <div className="bg-dark-900 border border-white/10 p-6 rounded-2xl flex-shrink-0 relative w-full md:w-64 aspect-square flex flex-col items-center justify-center text-center">
               <BookOpen size={48} className="text-accent-400 mb-4" />
               <span className="text-xs font-bold uppercase tracking-wider text-primary-400 bg-primary-500/10 px-3 py-1 rounded-full mb-2">Published Paper</span>
               <span className="text-white font-bold opacity-50">IJCTT 2025</span>
            </div>

            <div className="flex-grow">
               <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">IoT-Based Plant Watering System</h3>
               <p className="text-primary-400 font-medium mb-6">Published in International Journal of Computer Trends and Technology (IJCTT, 2025)</p>
               
               <p className="text-slate-300 leading-relaxed mb-8">
                 A comprehensive study and implementation of an automated irrigation system utilizing sensor networks and microcontrollers. The research focused on establishing a highly efficient closed-loop feedback mechanism to monitor soil health securely.
               </p>

               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 {[
                   "Built with Arduino/ESP32 & NodeMCU",
                   "Integrated Blynk IoT Platform",
                   "Reduced water waste by 44%",
                   "Implemented closed-loop feedback system"
                 ].map((metric, i) => (
                   <div key={i} className="flex items-center gap-2 text-slate-200">
                     <CheckCircle size={18} className="text-accent-500" />
                     <span className="font-medium text-sm">{metric}</span>
                   </div>
                 ))}
               </div>
            </div>

          </div>
        </motion.div>
      </div>
    </section>
  );
}

import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 relative bg-dark-900 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.5 }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary-500 to-accent-500 mx-auto rounded-full mb-6"></div>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            I'm currently seeking internship opportunities where I can contribute, learn, and grow. Whether you have a question or just want to say hi, I'll try my best to get back to you!
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          <motion.div
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.5, delay: 0.2 }}
             className="space-y-8"
          >
            <div className="glass p-8 rounded-2xl flex items-center gap-6 group hover:border-primary-500/30 transition-colors">
              <div className="p-4 bg-primary-500/10 rounded-full text-primary-400 group-hover:bg-primary-500 group-hover:text-white transition-colors">
                <Mail size={28} />
              </div>
              <div>
                <p className="text-sm text-slate-400 uppercase tracking-wider font-semibold mb-1">Email</p>
                <a href="mailto:saifamd65@gmail.com" className="text-lg font-medium text-white hover:text-primary-400 transition-colors">
                  saifamd65@gmail.com
                </a>
              </div>
            </div>

            <div className="glass p-8 rounded-2xl flex items-center gap-6 group hover:border-accent-500/30 transition-colors">
              <div className="p-4 bg-accent-500/10 rounded-full text-accent-400 group-hover:bg-accent-500 group-hover:text-white transition-colors">
                <Phone size={28} />
              </div>
              <div>
                <p className="text-sm text-slate-400 uppercase tracking-wider font-semibold mb-1">Phone</p>
                <a href="tel:+919310118979" className="text-lg font-medium text-white hover:text-accent-400 transition-colors">
                  +91 9310118979
                </a>
              </div>
            </div>

            <div className="glass p-8 rounded-2xl flex items-center gap-6 group hover:border-purple-500/30 transition-colors">
              <div className="p-4 bg-purple-500/10 rounded-full text-purple-400 group-hover:bg-purple-500 group-hover:text-white transition-colors">
                <MapPin size={28} />
              </div>
              <div>
                <p className="text-sm text-slate-400 uppercase tracking-wider font-semibold mb-1">Location</p>
                <p className="text-lg font-medium text-white">
                  India
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
             initial={{ opacity: 0, x: 20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.5, delay: 0.4 }}
          >
            <form className="glass-card p-8 rounded-2xl space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 <div>
                   <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">Your Name</label>
                   <input type="text" id="name" className="w-full bg-dark-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all font-medium" placeholder="John Doe" />
                 </div>
                 <div>
                   <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">Your Email</label>
                   <input type="email" id="email" className="w-full bg-dark-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all font-medium" placeholder="john@example.com" />
                 </div>
              </div>
              
              <div>
                 <label htmlFor="subject" className="block text-sm font-medium text-slate-300 mb-2">Subject</label>
                 <input type="text" id="subject" className="w-full bg-dark-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all font-medium" placeholder="Internship Opportunity" />
              </div>

              <div>
                 <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">Message</label>
                 <textarea id="message" rows="5" className="w-full bg-dark-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all font-medium resize-none" placeholder="Hello Saif, I would like to..."></textarea>
              </div>

              <button type="button" className="w-full bg-gradient-to-r from-primary-500 to-accent-500 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all transform hover:-translate-y-1">
                Send Message <Send size={20} />
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

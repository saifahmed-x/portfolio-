# Saif Ahmed - Portfolio

This is a premium, modern React portfolio fully configured with Vite, Tailwind CSS, and Framer Motion.
It features a dark theme layout with sleek glassmorphism and scroll animations.

## Requirements
Make sure you have Node.js installed on your machine. You can download it from [nodejs.org](https://nodejs.org/).

## How to run locally

1. Open your terminal and navigate to this folder (`/Users/saifahmed/Desktop/portfolio`).
2. Run `npm install` to install all the dependencies (`react`, `framer-motion`, `lucide-react`, `tailwindcss`, etc.).
3. Run `npm run dev` to start the local development server.
4. Open the link provided in the terminal (usually `http://localhost:5173`) in your browser to view the portfolio!

## How to deploy on Vercel / Netlify

### Using Vercel (Recommended for Next.js/Vite)
1. Push your code to a new GitHub repository.
2. Go to [Vercel](https://vercel.com/) and sign in with GitHub.
3. Click "Add New Project" and import your repository.
4. Vercel will automatically detect that you're using Vite. 
5. The Build Command will be `npm run build` and Output Directory will be `dist`.
6. Click **Deploy**. In under a minute, your portfolio will be live!

### Using Netlify
1. Push your code to GitHub.
2. Go to [Netlify](https://www.netlify.com/) and log in.
3. Click "Add new site" -> "Import an existing project".
4. Select GitHub and authorize, then choose your repository.
5. Build settings should automatically populate:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Click **Deploy Site**.

## Editing Content
All content is cleanly separated into modular components inside the `src/components/` folder:
- To edit your primary skills, modify `src/components/Skills.jsx`.
- To update your projects or links, modify `src/components/Projects.jsx`.
- Colors and typography are managed via `tailwind.config.js` and `src/index.css`.
